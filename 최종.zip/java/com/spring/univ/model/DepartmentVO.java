package com.spring.univ.model;

public class DepartmentVO {

	/////////////////////////////////////////////////////////////////////
	
	private String deptCode;     // 학과코드
	private String deptName;     // 학과명
	private String deptLocation; // 학과위치
	
	/////////////////////////////////////////////////////////////////////
	
	public DepartmentVO() {}
	
	public DepartmentVO(String deptCode, String deptName, String deptLocation) {
		this.deptCode = deptCode;
		this.deptName = deptName;
		this.deptLocation = deptLocation;
	}
	public String getDeptCode() {
		return deptCode;
	}
	public void setDeptCode(String deptCode) {
		this.deptCode = deptCode;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public String getDeptLocation() {
		return deptLocation;
	}
	public void setDeptLocation(String deptLocation) {
		this.deptLocation = deptLocation;
	}
	
}
